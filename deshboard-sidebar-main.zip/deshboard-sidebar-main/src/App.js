import React from 'react';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import People from './pages/People';
import Overview from './pages/Overview';
import { FaBell, FaUserCircle } from 'react-icons/fa'; // Import icons

const App = () => {
  const userName = 'John Doe'; // Dynamic user name

  return (
    <BrowserRouter>
      <div className="flex justify-between items-center p-4 border-b">
        <h2 className="text-3xl text-purple-500 font-semibold">PEOPLE.CO</h2>
        <div className="flex items-center space-x-4">
          <FaBell className="text-black-400 text-2xl" />
          <div className="flex items-center space-x-2">
            <FaUserCircle className="text-black-400 text-2xl" />
            <span className="text-black-600 text-lg font-medium">{userName}</span>
          </div>
        </div>
      </div>
      <Sidebar>
        <Routes>
          <Route path="/overview" element={<Overview />} />
          <Route path="/people" element={<People />} />
        </Routes>
      </Sidebar>
    </BrowserRouter>
  );
};

export default App;
