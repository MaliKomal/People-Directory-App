// src/components/Sidebar.js
import React from 'react';
import { Link } from 'react-router-dom';
import { FaHome, FaUsers } from 'react-icons/fa'; // Import the necessary icons

const Sidebar = ({ children }) => {
  return (
    <div className="flex ">
      <div className="w-64 bg-white-800 text-black-500 h-screen p-4">
        <div className="flex flex-col space-y-4">
          <Link to="/overview" className="flex items-center text-black-300 hover:text-blue-500">
            <FaHome className="text-xl mr-3" />
            <span>Overview</span>
          </Link>
          <Link to="/people" className="flex items-center text-black-300 hover:text-blue-500">
            <FaUsers className="text-xl mr-3" />
            <span>People</span>
          </Link>
        </div>
      </div>
      <div className="flex-1 p-6">
        {children}
      </div>
    </div>
  );
};

export default Sidebar;
