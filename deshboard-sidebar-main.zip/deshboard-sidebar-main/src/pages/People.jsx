import React, { useState, useEffect } from 'react';
import { FaSearch, FaPlus } from 'react-icons/fa'; // Importing icons for search and add

const People = () => {
  const [data, setData] = useState(() => {
    const savedData = localStorage.getItem('peopleData');
    return savedData
      ? JSON.parse(savedData)
      : [
          { id: 1, name: 'John Doe', email: 'john@example.com', status: 'Active', role: 'Developer', address: '123 Main St' },
          { id: 2, name: 'Jane Smith', email: 'jane@example.com', status: 'Inactive', role: 'Designer', address: '456 Park Ave' },
          { id: 3, name: 'Om Doe', email: 'om@example.com', status: 'Active', role: 'Developer', address: '123 Main St' },
          { id: 4, name: 'Rahi Smith', email: 'rahi@example.com', status: 'Inactive', role: 'Designer', address: '456 Park Ave' },
          // Add more data here...
        ];
  });

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5); // Change this to show more items per page
  const [newPerson, setNewPerson] = useState({ name: '', email: '', status: 'Active', role: '', address: '' });
  const [editing, setEditing] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [showDeletePopup, setShowDeletePopup] = useState(false);
  const [deletePerson, setDeletePerson] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    localStorage.setItem('peopleData', JSON.stringify(data));
  }, [data]);

  const handleDelete = () => {
    setData(data.filter((person) => person.id !== deletePerson.id));
    setShowDeletePopup(false);
  };

  const handleAddPerson = () => {
    if (editing) {
      setData(
        data.map((person) =>
          person.id === editing.id ? { ...person, ...newPerson } : person
        )
      );
      setEditing(null);
    } else {
      const id = data.length ? data[data.length - 1].id + 1 : 1;
      setData([...data, { id, ...newPerson }]);
    }
    setNewPerson({ name: '', email: '', status: 'Active', role: '', address: '' });
    setShowPopup(false);
  };

  const handleEdit = (person) => {
    setNewPerson(person);
    setEditing(person);
    setShowPopup(true);
  };

  const confirmDelete = (person) => {
    setDeletePerson(person);
    setShowDeletePopup(true);
  };

  const filteredData = data.filter(
    (person) =>
      person.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      person.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredData.slice(indexOfFirstItem, indexOfLastItem);

  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(filteredData.length / itemsPerPage); i++) {
    pageNumbers.push(i);
  }

  const handlePrevious = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < pageNumbers.length) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <span className="font-bold mr-4">Team Members ({filteredData.length})</span>
          <input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="p-2 border-2 border-blue-500 rounded"
          />
        </div>
        <button
          onClick={() => setShowPopup(true)}
          className="flex items-center bg-blue-500 text-white py-2 px-4 border-2 border-blue-500 rounded hover:bg-blue-600"
        >
          <FaPlus className="mr-2 text-xl" /> Add Member
        </button>
      </div>

      <div className="overflow-x-auto border-2 border-blue-500 rounded-lg p-2">
        <table className="min-w-full bg-white shadow-lg rounded-lg">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-4 text-center font-semibold border-b">Name</th>
              <th className="p-4 text-center font-semibold border-b">Email</th>
              <th className="p-4 text-center font-semibold border-b">Role</th>
              <th className="p-4 text-center font-semibold border-b">Address</th>
              <th className="p-4 text-center font-semibold border-b">Status</th>
              <th className="p-4 text-center font-semibold border-b">Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentItems.map((person, index) => (
              <tr
                key={person.id}
                className={`${
                  index % 2 === 0 ? 'bg-gray-50' : 'bg-white'
                } hover:bg-gray-100 transition-colors duration-200`}
              >
                <td className="p-4 text-center border-b">{person.name}</td>
                <td className="p-4 text-center border-b">{person.email}</td>
                <td className="p-4 text-center border-b">{person.role}</td>
                <td className="p-4 text-center border-b">{person.address}</td>
                <td className="p-4 text-center border-b">
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${
                      person.status === 'Active'
                        ? 'bg-green-200 text-green-800'
                        : 'bg-red-200 text-red-800'
                    }`}
                  >
                    {person.status}
                  </span>
                </td>
                <td className="p-4 text-center border-b flex justify-center space-x-2">
                  <button
                    onClick={() => handleEdit(person)}
                    className="text-blue-500 hover:underline"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => confirmDelete(person)}
                    className="text-red-500 hover:underline"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Pagination */}
        <div className="flex justify-between items-center mt-4">
          <button
            onClick={handlePrevious}
            disabled={currentPage === 1}
            className={`${
              currentPage === 1 ? 'bg-gray-300 cursor-not-allowed' : 'bg-blue-500 hover:bg-blue-600'
            } text-white py-2 px-4 rounded-l`}
          >
            Previous
          </button>

          <div className="flex space-x-2">
            {pageNumbers.map((number) => (
              <button
                key={number}
                onClick={() => setCurrentPage(number)}
                className={`${
                  number === currentPage ? 'bg-blue-500 text-white' : 'bg-gray-300'
                } py-2 px-4 rounded`}
              >
                {number}
              </button>
            ))}
          </div>

          <button
            onClick={handleNext}
            disabled={currentPage === pageNumbers.length}
            className={`${
              currentPage === pageNumbers.length
                ? 'bg-gray-300 cursor-not-allowed'
                : 'bg-blue-500 hover:bg-blue-600'
            } text-white py-2 px-4 rounded-r`}
          >
            Next
          </button>
        </div>
      </div>

      {showPopup && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded shadow-lg w-full max-w-md">
            <h2 className="text-2xl font-semibold mb-4">{editing ? 'Update Person' : 'Add New Person'}</h2>
            <div className="grid grid-cols-1 gap-4">
              <input
                type="text"
                placeholder="Name"
                value={newPerson.name}
                onChange={(e) => setNewPerson({ ...newPerson, name: e.target.value })}
                className="p-2 border border-gray-300 rounded"
              />
              <input
                type="email"
                placeholder="Email"
                value={newPerson.email}
                onChange={(e) => setNewPerson({ ...newPerson, email: e.target.value })}
                className="p-2 border border-gray-300 rounded"
              />
              <input
                type="text"
                placeholder="Role"
                value={newPerson.role}
                onChange={(e) => setNewPerson({ ...newPerson, role: e.target.value })}
                className="p-2 border border-gray-300 rounded"
              />
              <input
                type="text"
                placeholder="Address"
                value={newPerson.address}
                onChange={(e) => setNewPerson({ ...newPerson, address: e.target.value })}
                className="p-2 border border-gray-300 rounded"
              />
              <select
                value={newPerson.status}
                onChange={(e) => setNewPerson({ ...newPerson, status: e.target.value })}
                className="p-2 border border-gray-300 rounded"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
            <div className="mt-6 flex justify-end space-x-4">
              <button
                onClick={() => setShowPopup(false)}
                className="bg-gray-300 hover:bg-gray-400 text-gray-800 py-2 px-4 rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleAddPerson}
                className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded"
              >
                {editing ? 'Update' : 'Add'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showDeletePopup && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded shadow-lg w-full max-w-sm">
            <h2 className="text-xl font-semibold mb-4">Confirm Delete</h2>
            <p>Are you sure you want to delete {deletePerson?.name}?</p>
            <div className="mt-6 flex justify-end space-x-4">
              <button
                onClick={() => setShowDeletePopup(false)}
                className="bg-gray-300 hover:bg-gray-400 text-gray-800 py-2 px-4 rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="bg-red-500 hover:bg-red-600 text-white py-2 px-4 rounded"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default People;
