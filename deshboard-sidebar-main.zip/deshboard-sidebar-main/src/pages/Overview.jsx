import React from 'react';

const Overview= () => {
    return (
        <div className="border-4 border-black-500 w-full">
            <h1 className='text-4xl font-bold'>Welcome, John Doe!!!</h1>
        </div>
    );
};

export default Overview;