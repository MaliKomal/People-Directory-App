// src/data/fakeData.js
import { faker } from '@faker-js/faker';

export const generateFakeData = (num = 100) => {
    return Array.from({ length: num }, () => ({
        id: faker.datatype.uuid(),
        name: faker.name.fullName(),
        email: faker.internet.email(),
        role: faker.name.jobTitle(),
        team: faker.commerce.department(),
        status: faker.helpers.arrayElement(['Active', 'Inactive']),
    }));
};
